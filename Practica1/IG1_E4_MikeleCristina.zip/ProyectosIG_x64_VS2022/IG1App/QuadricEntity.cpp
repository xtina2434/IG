#include "QuadricEntity.h"

QuadricEntity::QuadricEntity() {
	q = gluNewQuadric();
}