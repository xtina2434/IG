#include "AdvancedTIE.h"

AdvancedTIE::AdvancedTIE()
{}
AdvancedTIE::~AdvancedTIE() {

}